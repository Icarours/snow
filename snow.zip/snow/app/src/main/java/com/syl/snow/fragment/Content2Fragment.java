package com.syl.snow.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.syl.snow.R;
import com.syl.snow.activity.Content2Activity;
import com.syl.snow.base.BaseFragment;
import com.syl.snow.bean.TitleBean;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by Bright on 2018/12/8.
 *
 * @Describe 模块2的标题
 * @Called
 */
public class Content2Fragment extends BaseFragment {
    @Bind(R.id.rv_title2)
    RecyclerView mRvTitle2;
    private List<TitleBean> mList;

    @Override
    public void initData() {
        mList = new ArrayList<>();
        for (int i = 0; i < 60; i++) {
            mList.add(new TitleBean(i,"content2 title--" + i, "content2 desc --" + i));
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_content2, container, false);
        ButterKnife.bind(this, rootView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRvTitle2.setLayoutManager(linearLayoutManager);
        mRvTitle2.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));
        Content2Adapter adapter = new Content2Adapter(R.layout.rv_title, mList);
        mRvTitle2.setAdapter(adapter);
        adapter.setOnItemClickListener((adapter1, view, position) -> {
            Intent intent = new Intent(getContext(),Content2Activity.class);
            intent.putExtra("title",mList.get(position));
            startActivity(intent);
            Toast.makeText(getContext(), "clicked---"+position, Toast.LENGTH_SHORT).show();
        });
        return rootView;
    }

    class Content2Adapter extends BaseQuickAdapter<TitleBean, BaseViewHolder> {
        public Content2Adapter(int layoutResId, @Nullable List<TitleBean> data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, TitleBean item) {
            helper.setText(R.id.tv_title, item.getTitle())
                    .setText(R.id.tv_desc, item.getDescription());
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }
}
